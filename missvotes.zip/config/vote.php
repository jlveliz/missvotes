<?php

return [

	'type-membership-default' => 'free',
	
	'vote-default' => 1,

	'raffle-numbers'=>2000,

	'vote-raffle-point'=>5,

	'vote-raffle-price'=>5.00,

];