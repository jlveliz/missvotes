<?php
namespace  MissVote\RepositoryInterface;

interface  PrecandidateRepositoryInterface extends CoreRepositoryInterface {
}