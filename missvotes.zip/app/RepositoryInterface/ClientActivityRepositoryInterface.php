<?php
namespace  MissVote\RepositoryInterface;

interface  ClientActivityRepositoryInterface extends CoreRepositoryInterface {
	
}