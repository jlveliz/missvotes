<?php
namespace  MissVote\RepositoryInterface;

interface  MembershipRepositoryInterface extends CoreRepositoryInterface {
	
}