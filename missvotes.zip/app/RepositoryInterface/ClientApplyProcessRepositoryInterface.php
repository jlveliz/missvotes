<?php
namespace  MissVote\RepositoryInterface;

interface  ClientApplyProcessRepositoryInterface extends CoreRepositoryInterface {
}