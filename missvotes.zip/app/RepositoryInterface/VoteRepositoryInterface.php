<?php
namespace  MissVote\RepositoryInterface;

interface  VoteRepositoryInterface extends CoreRepositoryInterface {
	
	public function ranking();

		
}