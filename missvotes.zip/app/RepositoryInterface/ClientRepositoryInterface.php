<?php
namespace  MissVote\RepositoryInterface;

interface  ClientRepositoryInterface extends CoreRepositoryInterface {

	public function countUserMemberships();
	
}