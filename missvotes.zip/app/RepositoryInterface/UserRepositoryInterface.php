<?php
namespace  MissVote\RepositoryInterface;

interface  UserRepositoryInterface extends CoreRepositoryInterface {
	
}