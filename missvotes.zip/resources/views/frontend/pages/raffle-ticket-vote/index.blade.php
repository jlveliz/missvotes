@extends('layouts.frontend')
@section('css')
	<link rel="stylesheet" href="{{ asset('/public/css/raffles.css') }}">
@endsection
@section('content')
	<div class="row">
		<h1 class="text-center"> @lang('raffle_ticket.tittle_raffle')</h1>
	</div>
	
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				<div class="panel panel-warning">
					<div class="panel-heading" role="tab" id="headingOne">
				      <h4 class="panel-title">
				        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				          {{ trans('raffle_ticket.policies.title') }}
				        </a>
				      </h4>
					</div>
					<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
					    <div class="panel-body">
					        <ul>
		        				<li>{{ trans('raffle_ticket.policies.policy_1') }}</li>
		        				<li>{{ trans('raffle_ticket.policies.policy_2') }}</li>
		        				<li>{{ trans('raffle_ticket.policies.policy_3') }}</li>
		        				<li>{{ trans('raffle_ticket.policies.policy_4') }}</li>
		        				<li>{{ trans('raffle_ticket.policies.policy_5') }}</li>
					        </ul>
					        <p class="text-muted text-justify"><b>{{ trans('raffle_ticket.policies.note') }}</b></p>
					    </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	@if (Session::has('mensaje'))
		<div class="row">
			<div class="col-md-12 col-xs-12">
				<div class="alert alert-dismissible @if(Session::get('tipo_mensaje') == 'success') alert-info  @endif @if(Session::get('tipo_mensaje') == 'error') alert-danger  @endif" role="alert">
		  			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
		  			{{session('mensaje')}}
		   		</div>
				<div class="clearfix"></div>
			</div>
		</div>
	@endif

	<div class="row">
		{{-- tickets --}}
		<div class="col-md-9 col-xs-6">

			{{-- signals --}}
			<ul class="list-unstyled text-center list-inline">
				<li><i class="fa fa-square reserved-color fa-lg""></i> <b> {{ trans('raffle_ticket.signals.reserved') }}</b></li>
				<li><i class="fa fa-square selected-now-color fa-lg"> </i> <b> {{ trans('raffle_ticket.signals.selected') }}</b></li>
				<li><i class="fa fa-square available-color fa-lg"></i> <b> {{ trans('raffle_ticket.signals.available') }}</b></li>
			</ul>
			<hr>
			@foreach ($raffles as $key => $raffle)
				<form action="{{ route('list.buy.ticket.add') }}" method="POST">
					{{  csrf_field() }}
					<input type="hidden" name="raffle_number" value="{{ $raffle['raffle_number'] }}">
					<div class="col-md-2 col-xs-4">
						<div class="panel panel-success">
		  					<div class="panel-body body-ticket @if(existOnCart($raffle['raffle_number'])) selected-now @else available @endif">
								<h1 class="text-center"><b>{{ $raffle['raffle_number'] }}</b></h1>
		  					</div>
		  					<div class="panel-footer footer-ticket">
		  						<button class="btn btn-primary btn-block btn-xs text-center btn-add-cart-ticket" @if(existOnCart($raffle['raffle_number'])) disabled @endif title="{{ trans('raffle_ticket.add_cart') }}" alt="{{ trans('raffle_ticket.add_cart') }}"><i class="fa fa-cart-plus"></i></button>
		  					</div>
						</div>
					</div>
				</form>
			@endforeach
			<div class="clearfix"></div>
			<div class="row text-center">
				{{ $raffles->links() }}
			</div>
		</div>
		{{-- cart --}}
		<div class="col-md-3 col-xs-6">
			<div class="cart-place">
				<div class="panel panel-info">
					<div class="panel-heading">
						<div class="panel-title">
							<div class="row">
								<div class="col-xs-12">
									<h5><span class="glyphicon glyphicon-shopping-cart"></span> {{ trans('raffle_ticket.shopping_cart_title') }}</h5>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-body">
						@if (session()->has('cart'))
							<div class="row">
								@foreach (session()->get('cart') as $key =>  $item) 
									<div class="col-xs-4">
										<h6 class="product-name"><strong>Ticket # {{ $item['raffle_number'] }} </strong></h6>
									</div>
									<div class="col-xs-3">
										<h6><strong>{{ $item['points'] }} Pnts.</h6>
									</div>
									<div class="col-xs-3">
										<h6><strong>$ {{ $item['price'] }}</h6>
									</div>
									<div class="col-xs-2">
										<form action="{{ route('list.buy.ticket.remove') }}" method="POST">
											{{  csrf_field() }}
											<input type="hidden" name="ticket_index" value="{{$key}}">
											<input type="hidden" name="raffle_number" value="{{ $item['raffle_number'] }}">
											<button type="submit" class="btn btn-link btn-xs btn-remove" alt="{{ trans('raffle_ticket.delete_cart') }}" title="{{ trans('raffle_ticket.delete_cart') }}">
												<span class="glyphicon glyphicon-trash"> </span>
											</button>
										</form>
									</div>
								@endforeach
							</div>
							<hr>
						@else
							<p class="text-muted"><b>{{ trans('raffle_ticket.no_ticket_selected') }}</b></p>
							<hr>
						@endif
					</div>
					<div class="panel-footer">
						<div class="row text-center">
							<div class="col-xs-6">
								<h4 class="text-right">Total <strong>$ {{ session()->has('total_sum') ?  session()->get('total_sum') : "0.00" }}   </strong></h4>
							</div>
							<div class="col-xs-6">
								<form action="{{ route('website.paypal.buyticket') }}" method="post">
									{{  csrf_field() }}
									<button type="button" class="btn btn-success btn-block" alt="{{ trans('raffle_ticket.buy_ticket_button') }}" title="{{ trans('raffle_ticket.buy_ticket_button') }}">
										<i class="fa fa-paypal" aria-hidden="true"></i> {{ trans('raffle_ticket.buy_ticket_button') }}
									</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection