<div  class="modal fade" id="email-change-password" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="activation-message-success-container">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <h2>Correo enviado!</h2><br>
		  <p class="text-muted">Se ha enviado el correo para poder cambiar su contraseña. Por favor reviselo y siga las instrucciones</p>
		  <input type="submit" class="email btn btn-primary btn-block" value="Aceptar" data-dismiss="modal">
		</div>
	</div>
</div>