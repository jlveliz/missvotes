<div  class="modal fade" id="activation-modal" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="activationmodal-container">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <h1>Activación de Usuario</h1><br>
		  <p class="text-justify">El código de activación puede demorar hasta 30 minutos en llegar. Revise en su bandeja de correo no deseados.</p>
		  <form role="form" id="activation-form-content" action="#">
		    <div class="form-group">
		        <input type="email" class="form-control" name="email" id="activation-email" placeholder="Correo" autofocus>
		       <strong class="help-block"></strong>
		    </div>
		    <input type="submit" name="activation" id="activation" class="activation btn btn-primary btn-block activationmodal-submit" value="Enviar Código">
		  </form>
		</div>
	</div>
</div>


