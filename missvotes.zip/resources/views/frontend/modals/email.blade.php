<div  class="modal fade" id="email-modal" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="emailmodal-container">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <h1>Recuperar Contraseña</h1><br>
		  <form role="form" id="email-form-content" action="#">
		    <div class="form-group">
		        <input type="email" class="form-control" name="email" id="email-email" placeholder="Correo" autofocus>
		        <strong class="help-block"></strong>
		    </div>
		    <input type="submit" name="button" id="email" class="email btn btn-primary btn-block loginmodal-submit" value="Recuperar Contraseña">
		  </form>
		</div>
	</div>
</div>