<div  class="modal fade" id="activation-message-success-modal" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="activation-message-success-container">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <h2>Correo enviado!</h2><br>
		  <p class="text-muted">Se ha enviado el correo de activación. Por favor revise su correo.</p>
		  <input type="submit" class="email btn btn-primary btn-block activation-message-success-container-submit" value="Aceptar" data-dismiss="modal">
		</div>
	</div>
</div>