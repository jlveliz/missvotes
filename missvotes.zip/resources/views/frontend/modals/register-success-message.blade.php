<div  class="modal fade" id="register-message-success-modal" tabindex="1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="register-message-success-container">
		   <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <h2>Registro completo!</h2><br>
		  <p class="text-muted text-center">Su cuenta se creó correctamente, pero debemos verificar su correo electrónico. Hemos enviado un correo de confirmación a su bandeja de entrada. Simplemente debe hacer clic en el enlace que reciba para activar su cuenta. No olvide buscar también en su bandeja de correos no deseados. ¡Gracias!</p>
		  <input type="submit" class="email btn btn-primary btn-block register-message-success-container-submit" value="Aceptar" data-dismiss="modal">
		</div>
	</div>
</div>