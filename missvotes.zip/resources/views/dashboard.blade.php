@extends('layouts.backend')

@section('content')
    <div class="panel panel-default">
        <div class="panel-heading">Escritorio</div>

        <div class="panel-body">
            You are logged in!
        </div>
    </div>
@endsection
