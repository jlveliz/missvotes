<?php

	return [
		'general_error' => 'Ocurrió un error',
		'paypal_error_connection' => 'Ocurrió un error de conexión con Paypal.', 
		'paypal_error_transaction' => 'Ocurrió un error en la transacción con Paypal.',
		'thanks_buy_membership'=>'Gracias por la compra de la membresía ',
		'error_buy_membership'=>'Ocurrió un problema al procesar el pago, intente nuevamente.',

		'pay_apply' => 'Gracias por su pago, por favor llene el formulario de inscripción',
		'error_pay_apply' => 'Ocurrió un error en la transacción con Su tarjeta de crédito.',
	];