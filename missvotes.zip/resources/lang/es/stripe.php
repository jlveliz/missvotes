<?php
	
	return [
		'pay_membership' => 'Pago de membresia ',
		'update_membership'=>'ha actualizado su membresía a ',
		'thanks_buy_membership'=>'Gracias por la compra de la membresía ',
		'error_buy_membership'=>'Ocurrió un problema al procesar el pago, intente nuevamente.',

		'pay_apply' => 'Gracias por su pago, por favor llene el formulario de inscripción',
		'error_pay_apply' => 'Ocurrió un error en la transacción con Su tarjeta de crédito.',
	];

