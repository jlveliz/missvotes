<?php

return [
	'credits' => 'Todos los derechos reservados',
	'update_membership'=>'Actualice su membresía',
	'apply_now' => 'Postularse',
	'win_travel' => 'Gane un viaje',
	'my_account' => 'Mi Cuenta',
	'go_administration' => 'Ir a Administración',
	'logout' => 'Salir'
];