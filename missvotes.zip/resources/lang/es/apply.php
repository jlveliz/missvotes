<?php
	return [

		'button-nav' => 'Postularse'

	];