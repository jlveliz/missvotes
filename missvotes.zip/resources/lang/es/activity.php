<?php 

	return [
		'vote' => 'Has votado :value  por :candidate',

		'ticket' => [
			'used' => 'Ha usado un ticket :name',
			'bought'=> 'Ha comprado un ticket :name',
		],

		'membership'=>[
			'bought' => 'Ha actualizado su membresia a :name',
		],

		'auth' => [
			'change_password' => 'Ha cambiado su contraseña',
			'update_profile' =>'Ha actualizado su perfil',
		],
	];