<?php

return [
	
	'tab_name' => 'Perfil',
	'edit_profile'=>'Editar Perfil',
	'cancel_edit_profile'=>'Cancelar',
	'personal_data' => 'Información Personal',
	'name_data' => 'Nombre',
	'last_name_data' => 'Apellido',
	'email_data' => 'Correo',
	'country_data' => 'País',
	'city_data' => 'Ciudad',
	'adress_data' => 'Dirección',
	'last_login_data' => 'Último acceso',
	'btn_save_data' => 'Guardar',
	'new_pass_data' => 'Nueva contraseña',
	'repeat_pass_data' => 'Repetir contraseña nueva',
	'btn_change_pass_data' => 'Cambiar contraseña',
	'btn_save_data' => 'Guardar',
	'membership_tab_data' => 'Membresía',
	'be_btn_data' => 'Postúlese a Candidata de',
	'status_apply'=>'Revise estado de postulación',
	'admin_btn_data' => 'Ir a administración',
	'activities_tab_data' => 'Mis actividades',
	'img_btn_data' => 'Cambiar imágen',
	'event_lbl_data' => 'Evento',
	'd_event_lbl_data' => 'Fecha de Evento',
	'you' => 'You'

];