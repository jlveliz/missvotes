<?php


	return [

		'token' => 'El correo es inválido'

	];