<?php 

	return [
		'vote' => 'Has voted :value  for :candidate',

		'ticket' => [
			'used' => 'has been used a ticket :name',
			'bought'=> 'Has bought a :name',
		],

		'membership'=>[
			'bought' => 'Have updated your membership to :name',
		],

		'auth' => [
			'change_password' =>'Have changed your password',
			'update_profile' =>'Have updated your profile',
		],
	];