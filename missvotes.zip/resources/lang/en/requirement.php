<?php

return [
	
	'tittle_process' => 'APPLICATION PROCESS',
	'accept_requirements_message' => 'Please accept the terms and conditions of participation', 
	'txt_01' => 'Be native of the country she wants to represents.',
	'txt_02' => 'Must be a female by birth.',
	'txt_03' => 'Know the history, economic and political situation of her country.',
	'txt_04' => 'Age 18 to 28 years: The candidate must be 18 years or have it before the event. The candidate must be 28 years old when starting the event and turn 29 years before October of the following year.',
	'txt_05' => 'Minimum study: High School or equivalent.',
	'txt_06' => 'Minimum height without footwear: 5.5 ft. / 1.65 cm (not less than the height established here)',
	'txt_07' => 'Beautiful aesthetic harmony of face and body',
	'txt_08' => 'Enjoy perfect physical and mental health.',
	'txt_09' => 'Weight provided according to her height.',
	'txt_10' => 'Never having been married.',
	'txt_11' => 'Never have children.',
	'txt_12' => 'Ease of corporal and oral expression.',
	'txt_13' => 'Have valid passport of the country of origin or birth certificate',
	'txt_14' => 'Have good manners and have never commit felonies.',
	'txt_15' => 'To develop a tourism idea about her country of origin.',
	'txt_16' => 'Accept the rules and discipline of the Miss Panamerican International competition.',
	'txt_terms' => 'The candidate accepts to possess the characteristics and requirements mentioned above to represent her country.',
	'btn_accept' => 'ACCEPT',

];