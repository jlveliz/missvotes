<?php

return [
	'credits' => 'All rights reserved',
	'update_membership'=>'Update your Membership',
	'apply_now' => 'Apply Now',
	'win_travel' => 'Win a travel',
	'my_account' => 'My Account',
	'go_administration' => 'Go to Admin',
	'logout' => 'Logout'
];