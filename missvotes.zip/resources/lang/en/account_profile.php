<?php

return [
	
	'tab_name' => 'Profile',
	'edit_profile'=>'Edit Profile',
	'cancel_edit_profile'=>'Cancel',
	'personal_data' => ' Basic Information ',
	'name_data' => 'Name',
	'last_name_data' => 'Lastname',
	'email_data' => 'Email',
	'country_data' => 'Country',
	'city_data' => 'City',
	'adress_data' => 'Adress',
	'last_login_data' => 'Last Login',
	'change_pass_data' => 'Change Password',
	'new_pass_data' => 'New Password',
	'repeat_pass_data' => 'Repeat New Password',
	'btn_change_pass_data' => 'Change Password',
	'btn_save_data' => 'Save',
	'membership_tab_data' => 'Membership',
	'be_btn_data' => 'Be a contestant',
	'status_apply'=>'View apply status of',
	'admin_btn_data' => 'Control Panel',
	'activities_tab_data' => 'My activities',
	'img_btn_data' => 'Change image',
	'event_lbl_data' => 'Event',
	'd_event_lbl_data' => 'Event Date',
	'you' => 'You'

];