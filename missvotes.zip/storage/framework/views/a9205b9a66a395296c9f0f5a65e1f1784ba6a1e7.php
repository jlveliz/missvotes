<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/profile.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-page">

	<?php if(Session::has('payment-message')): ?>
		<div class="row">
	        <div class="alert alert-dismissible <?php if(Session::get('payment-type') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('payment-type') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
	          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
	          <?php echo e(session('payment-message')); ?>

	        </div>
		</div>
        <div class="clearfix"></div>
    <?php endif; ?>

	<h2><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?></h2>
	<div class="container-tabs-profile">
		<ul class="nav nav-tabs" role="tablist">
		     <li role="presentation" class="active" >
		    	<a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"> <?php echo app('translator')->get('account_profile.tab_name'); ?> </a>
		    </li>
		    <?php if(!Auth::user()->is_admin): ?>
			    <li role="presentation">
			    	<a href="#membership" aria-controls="membership" role="tab" data-toggle="tab"><?php echo app('translator')->get('account_profile.membership_tab_data'); ?> <?php if(Auth::user()->client && !Auth::user()->client->current_membership()): ?> <small class="upgrade-membership">(Premium!!)</small> <?php endif; ?></a>
			    </li>
			    <li role="presentation">
			    	<a href="#tickets" aria-controls="tickets" role="tab" data-toggle="tab"><?php echo e(trans('raffle_ticket.tab_name')); ?></a>
			    </li>
			    <li role="presentation">
			    	<a href="#activity" aria-controls="activity" role="tab" data-toggle="tab"><?php echo app('translator')->get('account_profile.activities_tab_data'); ?></a>
			    </li>
		    <?php endif; ?>
  		</ul>

  		<!-- Tab panes -->
		<div class="tab-content">
			<div role="tabpanel" class="tab-pane active" id="profile">
		    	<div class="col-md-3 col-sm-3 col-xs-12">
		    		<a href="#" id="profile-section">
		    			<hr>
		    			<div class="profile-img" style="background-image: url(<?php if(Auth::user()->client->photo): ?> '<?php echo e(config('app.url').'/'. Auth::user()->client->photo); ?>' <?php else: ?> '<?php echo e(asset('public/images/account.png')); ?>'  <?php endif; ?>)" alt="<?php echo e(Auth::user()->name); ?>" title="<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?>">
		    			</div>
		    			<div class="middle">
                        	<div class="text"><?php echo app('translator')->get('account_profile.img_btn_data'); ?></div>
                    	</div>
		    		</a>
		    		<form id="form-update-photo" action="<?php echo e(route('website.account.update')); ?>" enctype="multipart/form-data" method="POST">
		    			<?php echo e(csrf_field()); ?>

		    			<input type="file" id="file-profile-upload" name="photo" type="file" accept="image/*"/ style="display: none">
		    		</form>
		    		<hr>
		    		<div class="row" class="section-profile-buttons">
			    		<div class="text-center">
			    		<?php if(Auth::user()->is_admin): ?>
			    			<a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.admin_btn_data'); ?>" title="Ir a Administración"> <i class="fa fa-code"></i><?php echo app('translator')->get('account_profile.admin_btn_data'); ?></a>
			    		<?php else: ?>
			    			<?php if(Auth::user()->client->hasApply()): ?>
			    				<a href="<?php echo e(route('apply.requirements')); ?>" class="btn btn-apply btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>" title="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>"><?php echo app('translator')->get('account_profile.status_apply'); ?> <br> <?php echo e(config('app.name')); ?>		</a>
			    			<?php else: ?>
			    				<a href="<?php echo e(route('apply.requirements')); ?>" class="btn btn-apply btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>" title="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>"><?php echo app('translator')->get('account_profile.be_btn_data'); ?> <br> <?php echo e(config('app.name')); ?>		</a>
			    			<?php endif; ?>
			    		<?php endif; ?>
			    		</div>
		    		</div>
		    	</div>
		    	<div class="col-md-9 col-sm-9 col-xs-12">
		    		<h4>
		    			<?php echo app('translator')->get('account_profile.personal_data'); ?>
		    			<?php if(session()->get('edit-account')): ?>
		    				<a href="<?php echo e(route('website.account.edit')); ?>" title="<?php echo e(trans('account_profile.cancel_edit_profile')); ?>" alt="<?php echo e(trans('account_profile.cancel_edit_profile')); ?>" class="btn btn-danger pull-right btn-xs"><i class="fa fa-ban"></i> <?php echo e(trans('account_profile.cancel_edit_profile')); ?></a>
		    			<?php else: ?>
		    				<a href="<?php echo e(route('website.account.edit')); ?>" title="<?php echo e(trans('account_profile.edit_profile')); ?>" alt="<?php echo e(trans('account_profile.edit_profile')); ?>" class="btn btn-primary pull-right btn-xs"><i class="fa fa-pencil"></i> <?php echo e(trans('account_profile.edit_profile')); ?></a>
		    			<?php endif; ?> 
		    		</h4>
		    		<?php if(Session::has('action')): ?>
						<div class="alert alert-dismissible <?php if(Session::get('tipo_mensaje') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('tipo_mensaje') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
								<?php echo e(session('mensaje')); ?>

							</div>
						<div class="clearfix"></div>
	   				<?php endif; ?>
			    		
		    		<?php if(!session()->get('edit-account')): ?>
			    		<table class="table table-striped ">
			    			<tbody>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.name_data'); ?>: </b> <?php echo e(Auth::user()->name); ?></td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.last_name_data'); ?>: </b> <?php echo e(Auth::user()->last_name); ?></td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.email_data'); ?>: </b> <?php echo e(Auth::user()->email); ?></td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.country_data'); ?>: </b> <?php if(Auth::user()->client->country): ?> <?php echo e(Auth::user()->client->country->name); ?> <?php else: ?> - <?php endif; ?> </td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.city_data'); ?>: </b> <?php echo e(Auth::user()->city); ?></td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.adress_data'); ?>: </b> <?php echo e(Auth::user()->address); ?></td>
			    				</tr>
			    				<tr>
			    					<td><b><?php echo app('translator')->get('account_profile.last_login_data'); ?>: </b> <?php echo e(Auth::user()->last_login); ?></td>
			    				</tr>
			    			</tbody>
			    		</table>
		    		<?php else: ?>
		    			<form class="form-horizontal" action="<?php echo e(route('website.account.update')); ?>" method="POST">
		    				<?php echo e(csrf_field()); ?>

			    		<div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
			    			<label for="name" id="name" class="col-sm-2 control-label text-left"><b><?php echo app('translator')->get('account_profile.name_data'); ?>: </b></label>
			    			<div class="col-sm-6">
			    				<input type="text" name="name" id="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
			    				<?php if($errors->has('name')): ?> <p class="help-block"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
			    			</div>
			    		</div>

			    		<div class="form-group <?php if($errors->has('last_name')): ?> has-error <?php endif; ?>">
			    			<label for="last_name" class="col-sm-2 control-label text-left"><b><?php echo app('translator')->get('account_profile.last_name_data'); ?>: </b></label>
			    			<div class="col-sm-6">
			    				<input type="text" name="last_name" id="last_name" class="form-control" value="<?php echo e(Auth::user()->last_name); ?>">
			    				<?php if($errors->has('last_name')): ?> <p class="help-block"><?php echo e($errors->first('last_name')); ?></p> <?php endif; ?>
			    			</div>
			    		</div>

			    		<div class="form-group <?php if($errors->has('country_id')): ?> has-error <?php endif; ?>">
			    			<label for="country_id" class="col-sm-2 control-label text-left"><b><?php echo app('translator')->get('account_profile.country_data'); ?>: </b></label>
			    			<div class="col-sm-6">
			    				<select name="country_id" id="country_id" class="form-control">
			    					<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			    						<option value="<?php echo e($country->id); ?>" <?php if($country->id == Auth::user()->country_id): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>	
			    					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			    				</select>
			    				<?php if($errors->has('country_id')): ?> <p class="help-block"><?php echo e($errors->first('country_id')); ?></p> <?php endif; ?>
			    			</div>
			    		</div>

			    		<div class="form-group <?php if($errors->has('city')): ?> has-error <?php endif; ?>">
			    			<label for="city" class="col-sm-2 control-label text-left"><b><?php echo app('translator')->get('account_profile.city_data'); ?>: </b></label>
			    			<div class="col-sm-6">
			    				<input type="text" name="city" id="city" class="form-control" value="<?php echo e(Auth::user()->city); ?>">
			    				<?php if($errors->has('city')): ?> <p class="help-block"><?php echo e($errors->first('city')); ?></p> <?php endif; ?>
			    			</div>
			    		</div>

			    		<div class="form-group <?php if($errors->has('address')): ?> has-error <?php endif; ?>">
			    			<label for="address" class="col-sm-2 control-label text-left"><b><?php echo app('translator')->get('account_profile.adress_data'); ?>: </b></label>
			    			<div class="col-sm-6">
			    				<input type="text" name="address" id="address" class="form-control" value="<?php echo e(Auth::user()->address); ?>">
			    				<?php if($errors->has('address')): ?> <p class="help-block"><?php echo e($errors->first('address')); ?></p> <?php endif; ?>
			    			</div>
			    		</div>
			    		<h4><?php echo app('translator')->get('account_profile.change_pass_data'); ?></h4>
			    			<div class="form-group col-md-4 col-sm-4 col-xs-12 <?php if($errors->has('password')): ?> has-error <?php endif; ?>" style="margin-right: 15px!important">
			    				<label class="control-label"><?php echo app('translator')->get('account_profile.new_pass_data'); ?> </label>
								<input type="password" class="form-control" placeholder="<?php echo app('translator')->get('account_profile.new_pass_data'); ?>" name="password" value="<?php echo e(old('password')); ?>">
								<?php if($errors->has('password')): ?> <p class="help-block"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
			    			</div>
			    			<div class="form-group col-md-4 col-sm-4 col-xs-12 <?php if($errors->has('repeat_password')): ?> has-error <?php endif; ?>" style="margin-right: 15px!important">
			    				<label class="control-label"><?php echo app('translator')->get('account_profile.repeat_pass_data'); ?> </label>
								<input type="password" class="form-control" placeholder="<?php echo app('translator')->get('account_profile.repeat_pass_data'); ?> " name="repeat_password" value="<?php echo e(old('repeat_password')); ?>">
								<?php if($errors->has('repeat_password')): ?> <p class="help-block"><?php echo e($errors->first('repeat_password')); ?></p> <?php endif; ?>
			    			</div>
			    			<div class="form-group col-md-12 col-xs-12 text-left">
			    				<br>
			    				<button type="submit" name="submit" class="btn btn-primary"> <?php echo app('translator')->get('account_profile.btn_save_data'); ?></button>
			    			</div>
			    		</form>
		    		<?php endif; ?>
		    	</div>
			</div>
		<?php if(!Auth::user()->is_admin): ?>
			    
			    <div role="tabpanel" class="tab-pane" id="membership" >
			    	<h4><?php echo app('translator')->get('account_profile.membership_tab_data'); ?></h4> 
			    	<div class="col-md-12 col-lg-12 col-xs-12">
			    		<?php echo $__env->make('frontend.partials.membership',$memberships, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			    	</div>
			    </div>

			    
			    <div role="tabpanel" class="tab-pane" id="tickets">
			    	<h4>Tickets</h4>
			    	<div class="col-md-12 col-lg-12 col-xs-12">
			    		
			    		<h5><b><?php echo e(trans('raffle_ticket.my_tickets')); ?></b></h5>
			    		<div class="row">
			    		<?php if(count(Auth::user()->client->activeTickets()) > 0): ?>
			    			<?php $__currentLoopData = Auth::user()->client->activeTickets(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketClient): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			    				<div class="col-xs-4 col-md-2">
			    					<div class="text-center">
				    					 <div class="panel panel-primary">
				    					 	<div class="panel-heading">
				    					 		<h3 class="panel-title"><span class="badge">x<?php echo e($ticketClient->counter); ?></span> <i class="fa fa-ticket" aria-hidden="true"></i> <?php echo e($ticketClient->ticket->name); ?></h3>
				    					 	</div>
				    					 	<div class="panel-body">
				    					 		<table class="table">
				    					 			<tbody>
				    					 				<tr>
				    					 					<td><b>Val: </b> <?php echo e($ticketClient->ticket->val_vote); ?> Puntos</td>
				    					 				</tr>
				    					 			</tbody>
				    					 		</table>
				    					 	</div>
				    					 </div>
			    					</div>
			    				</div>
			    			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				    		<?php else: ?>
				    			<p class="text-center text-warning">
				    				<b><?php echo e(trans('raffle_ticket.tickets_not_found')); ?></b>
								</p>
				    		<?php endif; ?>
			    		</div>
			    	</div>
			    </div>
			    
			<div role="tabpanel" class="tab-pane <?php if(Auth::user()->is_admin): ?> active <?php endif; ?>" id="profile">
		    	<div class="col-md-3 col-sm-3 col-xs-12 hidden-xs">
		    		<a href="#" id="profile-section">
		    			<hr>
		    			<div class="profile-img" style="background-image: url(<?php if(Auth::user()->client->photo): ?> '<?php echo e(config('app.url').'/'. Auth::user()->client->photo); ?>' <?php else: ?> '<?php echo e(asset('public/images/account.png')); ?>'  <?php endif; ?>)" alt="<?php echo e(Auth::user()->name); ?>" title="<?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?>">
		    			</div>
		    			<div class="middle">
                        	<div class="text"><?php echo app('translator')->get('account_profile.img_btn_data'); ?></div>
                    	</div>
		    		</a>
		    		<form id="form-update-photo" action="<?php echo e(route('website.account.update')); ?>" enctype="multipart/form-data" method="POST">
		    			<?php echo e(csrf_field()); ?>

		    			<input type="file" id="file-profile-upload" name="photo" type="file" accept="image/*"/ style="display: none">
		    		</form>
		    		<hr>
		    		<div class="row" class="section-profile-buttons">
			    		<div class="text-center">
			    		<?php if(Auth::user()->is_admin): ?>
			    			<a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.admin_btn_data'); ?>" title="Ir a Administración"> <i class="fa fa-code"></i><?php echo app('translator')->get('account_profile.admin_btn_data'); ?></a>
			    		<?php else: ?>
			    			<?php if(Auth::user()->client->hasApply()): ?>
			    				<a href="<?php echo e(route('apply.requirements')); ?>" class="btn btn-apply btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>" title="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>"><?php echo app('translator')->get('account_profile.status_apply'); ?> <br> <?php echo e(config('app.name')); ?>		</a>
			    			<?php else: ?>
			    				<a href="<?php echo e(route('apply.requirements')); ?>" class="btn btn-apply btn-block btn-lg" alt="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>" title="<?php echo app('translator')->get('account_profile.be_btn_data'); ?>"><?php echo app('translator')->get('account_profile.be_btn_data'); ?> <br> <?php echo e(config('app.name')); ?>		</a>
			    			<?php endif; ?>
			    		<?php endif; ?>
			    		</div>
		    		</div>
		    	</div>
		    	<div class="col-md-9 col-sm-9 col-xs-12">
		    		<h4><?php echo app('translator')->get('account_profile.personal_data'); ?></h4>
		    		<table class="table table-striped ">
		    			<tbody>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.name_data'); ?>: </b> <?php echo e(Auth::user()->name); ?></td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.last_name_data'); ?>: </b> <?php echo e(Auth::user()->last_name); ?></td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.email_data'); ?>: </b> <?php echo e(Auth::user()->email); ?></td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.country_data'); ?>: </b> <?php if(Auth::user()->client->country): ?> <?php echo e(Auth::user()->client->country->name); ?> <?php else: ?> - <?php endif; ?> </td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.city_data'); ?>: </b> <?php echo e(Auth::user()->city); ?></td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.adress_data'); ?>: </b> <?php echo e(Auth::user()->address); ?></td>
		    				</tr>
		    				<tr>
		    					<td><b><?php echo app('translator')->get('account_profile.last_login_data'); ?>: </b> <?php echo e(Auth::user()->last_login); ?></td>
		    				</tr>
		    			</tbody>
		    		</table>
		    		<h4><?php echo app('translator')->get('account_profile.change_pass_data'); ?></h4>
		    		<form action="<?php echo e(route('website.account.update')); ?>" method="POST">
		    			<?php if(Session::has('action') && Session::get('action') == 'update-password'): ?>
    						<div class="alert alert-dismissible <?php if(Session::get('tipo_mensaje') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('tipo_mensaje') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
      							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
      							<?php echo e(session('mensaje')); ?>

       						</div>
    						<div class="clearfix"></div>
   						<?php endif; ?>
		    			<?php echo e(csrf_field()); ?>

		    			<div class="form-group col-md-4 col-sm-4 col-xs-12 <?php if($errors->has('password')): ?> has-error <?php endif; ?>">
		    				<label class="control-label"><?php echo app('translator')->get('account_profile.new_pass_data'); ?> </label>
							<input type="password" class="form-control" placeholder="<?php echo app('translator')->get('account_profile.new_pass_data'); ?>" name="password" value="<?php echo e(old('password')); ?>">
							<?php if($errors->has('password')): ?> <p class="help-block"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
		    			</div>
		    			<div class="form-group col-md-4 col-sm-4 col-xs-12 <?php if($errors->has('repeat_password')): ?> has-error <?php endif; ?>">
		    				<label class="control-label"><?php echo app('translator')->get('account_profile.repeat_pass_data'); ?> </label>
							<input type="password" class="form-control" placeholder="<?php echo app('translator')->get('account_profile.repeat_pass_data'); ?> " name="repeat_password" value="<?php echo e(old('repeat_password')); ?>">
							<?php if($errors->has('repeat_password')): ?> <p class="help-block"><?php echo e($errors->first('repeat_password')); ?></p> <?php endif; ?>
		    			</div>
		    			<div class="form-group col-md-4 col-sm-4 col-xs-12" style="padding-top: 4px">
		    				<br>
		    				<button type="submit" name="submit" class="btn btn-default"><?php echo app('translator')->get('account_profile.btn_change_pass_data'); ?></button>
		    			</div>
		    		</form>
		    	</div>
		    </div>
			    <div role="tabpanel" class="tab-pane" id="activity">
			    	<h4><?php echo app('translator')->get('account_profile.activities_tab_data'); ?></h4>
			    	<div class="col-md-12 col-lg-12 col-xs-12">
			    		<table id="activity-datatable" class="table table-bordered" style="width: 100%">
					  		<thead>
						  		<tr>
						  			<th><?php echo app('translator')->get('account_profile.event_lbl_data'); ?></th>
						  			<th><?php echo app('translator')->get('account_profile.d_event_lbl_data'); ?></th>
						  		</tr>
					  		</thead>
	  						<tbody>
	  						<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	  						<tr>
	  							<td> <?php if($activity->params): ?>  <?php echo trans($activity->name,$activity->params); ?> <?php else: ?> <?php echo trans($activity->name); ?>  <?php endif; ?> </td>
	  							<td><?php echo e($activity->created_at); ?></td>
	  						</tr>
	  						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  						</tbody>
	  					</table>
			    	</div>
			    </div>
				
			<?php endif; ?>

		
		</div>
		    

	</div>
	<div class="clearfix"></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/jquery.dataTables.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/buttons.bootstrap.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/fixedHeader.bootstrap.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/scroller.bootstrap.min.css')); ?>" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/responsive.bootstrap.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
 <script src="<?php echo e(asset('public/js/moment/moment.js')); ?>"></script>
 <script src="<?php echo e(asset('public/js/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/buttons.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/responsive.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datatables/dataTables.scroller.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/datetime-moment.js')); ?>"></script>
<script src="https://checkout.stripe.com/checkout.js"></script>
<script type="text/javascript">

	var handlerMembership = StripeCheckout.configure({
	  key: '<?php echo e(config('services.stripe.key')); ?>',
	  image: '<?php echo e(asset('public/images/queen-mini.png')); ?>',
	  locale: 'auto',
	  name: '<?php echo e(config('app.name')); ?>',
	  token : function(token){
	  	$("#stripe-token").val(token.id);
	  	//submit the magic form :3
	  	$("#membeship-form").submit();
	  }
	});


	var handlerTicket = StripeCheckout.configure({
	  key: '<?php echo e(config('services.stripe.key')); ?>',
	  image: '<?php echo e(asset('public/images/queen-mini.png')); ?>',
	  locale: 'auto',
	  name: '<?php echo e(config('app.name')); ?>',
	  token : function(token){
	  	$("#stripe-ticket-token").val(token.id);
	  	//submit the magic form :3
	  	$("#ticket-form").submit();
	  }
	});

  $(document).ready(function(){


  	// Javascript to enable link to tab
  	var url = document.location.toString();
  	if (url.match('#')) {
  	    $('.nav-tabs a[href="#' + url.split('#')[1] + '-tab"]').tab('show');
  	} //add a suffix

  	// Change hash for page-reload
  	$('.nav-tabs a').on('shown.bs.tab', function (e) {
  	    window.location.hash = e.target.hash;
  	})

  	$.fn.dataTable.moment( 'dddd, MMMM Do, YYYY' );

      $('#activity-datatable').DataTable({
      	<?php if(App::isLocale('es')): ?>
        "language": {
          "url": "../public/js/datatables/json/es.json"
        },
        <?php else: ?>
        "language": {
          "url": "../public/js/datatables/json/en.json"
        },
        <?php endif; ?>
        "order": [[ 1, "desc" ]],
      });



      // CHECKOUT MEMBERSHIP
      $(".pay-membership-with-stripe").on('click', function(event) {
      	var _this = $(this);

      	//reset magic form
      	$("#membership-id").val('');
      	$("#stripe-token").val('');
      	$("#amount").val('');

      	//set membership on magic form
		$("#membership-id").val(_this.data('membership'));
      	$("#amount").val(_this.data('amount'));

      	handlerMembership.open({
    		description: _this.data('description'),
    		amount: _this.data('amount'),
    		email: _this.data('email')
  		});
      });


      // CHECKOUT TICKET
      $(".pay-ticket-with-stripe").on('click', function(event) {
      	var _this = $(this);

      	//reset magic form
      	$("#ticket-id").val('');
      	$("#stripe-ticket-token").val('');
      	$("#amount-ticket").val('');

      	//set membership on magic form
		$("#ticket-id").val(_this.data('ticket'));
      	$("#amount-ticket").val(_this.data('amount'));

      	handlerTicket.open({
    		description: _this.data('description'),
    		amount: _this.data('amount'),
    		email: _this.data('email')
  		});
      });

  });

  // Close Checkout on page navigation:
	window.addEventListener('popstate', function() {
  		handlerMembership.close();
  		handlerTicket.close();
	});
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>