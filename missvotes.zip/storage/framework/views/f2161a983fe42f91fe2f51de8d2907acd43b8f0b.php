<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title> <?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/app.css')); ?>">
	<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/errors.css')); ?>">
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>