<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href=" <?php echo e(asset('public/css/app.css')); ?> " rel="stylesheet">
    <link href=" <?php echo e(asset('public/css/backend.css')); ?> " rel="stylesheet">
    <link href=" <?php echo e(asset('/public/css/font-awesome.min.css')); ?> " rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/jquery.dataTables.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/buttons.bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/fixedHeader.bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/responsive.bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/js/datatables/scroller.bootstrap.min.css')); ?>" />
    <?php echo $__env->yieldContent('css'); ?>

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.name', 'Laravel')); ?>

                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <?php if(Auth::user() && Auth::user()->is_admin): ?> 
                       <ul class="nav navbar-nav">
                            <li class="<?php if(Request::path() == 'backend/dashboard'): ?> active <?php endif; ?>"><a href="<?php echo e(route('dashboard')); ?>">Escritorio <span class="sr-only">(current)</span></a></li>
                            
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Participantes <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li class="<?php if(Request::path() == 'backend/misses'): ?> active <?php endif; ?>">
                                        <a href="<?php echo e(route('misses.index')); ?>">Candidatas <span class="sr-only">(current)</span></a>
                                    </li>
                                    <li class="<?php if(Request::path() == 'backend/precandidates'): ?> active <?php endif; ?>">
                                        <a href="<?php echo e(route('precandidates.index')); ?>">Pre Candidatas <span class="sr-only">(current)</span></a>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Clientes <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li class="<?php if(Request::path() == 'backend/clients'): ?> active <?php endif; ?>">
                                        <a href="<?php echo e(route('clients.index')); ?>">Listado <span class="sr-only">(current)</span></a>
                                    </li>
                                     <li class="<?php if(Request::path() == 'backend/activities'): ?> active <?php endif; ?>"><a href="<?php echo e(route('activities.index')); ?>">Actividades<span class="sr-only">(current)</span></a></li>
                                </ul>
                            </li>
                            
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Configuración <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li class="<?php if(Request::path() == 'backend/users'): ?> active <?php endif; ?>"><a href="<?php echo e(route('users.index')); ?>">Usuarios <span class="sr-only">(current)</span></a></li>
                                    <li class="<?php if(Request::path() == 'backend/tickets-vote'): ?> active <?php endif; ?>"><a href="<?php echo e(route('tickets-vote.index')); ?>">Tickets <span class="sr-only">(current)</span></a></li>
                                     <li class="<?php if(Request::path() == 'backend/memberships'): ?> active <?php endif; ?>"><a href="<?php echo e(route('memberships.index')); ?>">Membresias <span class="sr-only">(current)</span></a></li>
                                </ul>
                            </li>
                            
                        </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::user() && Auth::user()->is_admin): ?>
                            <li>
                                <a href="<?php echo e(route('website.home')); ?>" title="Ir al sitio">Ir al sitio</a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->last_name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(url('backend/logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Salir
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('backend/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div id="panel-container">
                <div class="row">
                    <div class="col-md-12">
                        <?php echo $__env->yieldContent('content'); ?>    
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('public/js/app.js')); ?> "></script>
    <script src="<?php echo e(asset('public/js/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/buttons.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/responsive.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/datatables/dataTables.scroller.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
