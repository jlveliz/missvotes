<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
	<div class="panel-heading">Usuarios</div>
	<p class="subtitle">Creación de Usuarios</p>
	<div class="panel-body">
		<?php if(Session::has('mensaje')): ?>
        <div class="alert alert-dismissible <?php if(Session::get('tipo_mensaje') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('tipo_mensaje') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <?php echo e(session('mensaje')); ?>

           </div>
        <div class="clearfix"></div>
       <?php endif; ?>
		<form action="<?php echo e(route('users.store')); ?>" method="post">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="hidden" name="is_admin" value="1">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php echo e($error); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<div class="row">
				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
					<label class="control-label">Email </label>
					<input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
					<?php if($errors->has('email')): ?> <p class="help-block"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
				</div>

				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
					<label class="control-label">Nombre </label>
					<input type="text" class="form-control" placeholder="Nombre" name="name" value="<?php echo e(old('name')); ?>">
					<?php if($errors->has('name')): ?> <p class="help-block"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
				</div>

				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('last_name')): ?> has-error <?php endif; ?>">
					<label class="control-label">Apellido </label>
					<input type="text" class="form-control" placeholder="Apellido" name="last_name" value="<?php echo e(old('last_name')); ?>">
					<?php if($errors->has('name')): ?> <p class="help-block"><?php echo e($errors->first('last_name')); ?></p> <?php endif; ?>
				</div>

				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('address')): ?> has-error <?php endif; ?>">
					<label class="control-label">Dirección </label>
					<input type="text" class="form-control" placeholder="Dirección" name="address" value="<?php echo e(old('address')); ?>">
					<?php if($errors->has('address')): ?> <p class="help-block"><?php echo e($errors->first('address')); ?></p> <?php endif; ?>
				</div>
			</div>


			<div class="row">
				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('password')): ?> has-error <?php endif; ?>">
					<label class="control-label">Clave </label>
					<input type="password" class="form-control" placeholder="Clave" name="password" value="">
					<?php if($errors->has('password')): ?> <p class="help-block"><?php echo e($errors->first('password')); ?></p> <?php endif; ?>
				</div>

				<div class="form-group col-md-3 col-sm-3 col-xs-12 <?php if($errors->has('password_repeat')): ?> has-error <?php endif; ?>">
					<label class="control-label">Repetir Clave </label>
					<input type="password" class="form-control" placeholder="Clave" name="password_repeat" value="">
					<?php if($errors->has('password_repeat')): ?> <p class="help-block"><?php echo e($errors->first('password_repeat')); ?></p> <?php endif; ?>
				</div>
			</div>

			<div class="form-group  col-md-12 col-sm-12 col-xs-12">
				<a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Cancelar</a>
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>

		</form>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>