<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo e(config('app.name')); ?></title>
	<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/app.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/frontend.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/animate.min.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	 <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <div id="spinner">
        <div class="spinner" >
          <div class="rect1"></div>
          <div class="rect2"></div>
          <div class="rect3"></div>
          <div class="rect4"></div>
          <div class="rect5"></div>
        </div>
    </div>
	<header id="header">
        <?php if(Auth::user()): ?>
		  <?php echo $__env->make('frontend.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
	</header><!-- /header -->
	<div class="container container-app">
        <?php echo $__env->yieldContent('content'); ?>
		<footer class="row footer">
			<p class="text-center"><?php echo e(date('Y')); ?>© <?php echo e(trans('app.credits')); ?>.</p>
		</footer>
	</div>
    <script src="<?php echo e(asset('public/js/app.js')); ?> "></script>
    <script src="<?php echo e(asset('public/js/jquery-validation/dist/jquery.validate.min.js')); ?> "></script>
    <?php echo $__env->yieldContent('js'); ?>
    <script src="<?php echo e(asset('public/js/frontend-app.js')); ?> "></script>
    
    <?php echo $__env->make('frontend.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.activation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.activation-success-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.register-success-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.email', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('frontend.modals.email-change-password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>