<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('/public/css/raffles.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h1 class="text-center"> <?php echo app('translator')->get('raffle_ticket.tittle_raffle'); ?></h1>
	</div>
	
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				<div class="panel panel-warning">
					<div class="panel-heading" role="tab" id="headingOne">
				      <h4 class="panel-title">
				        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				          <?php echo e(trans('raffle_ticket.policies.title')); ?>

				        </a>
				      </h4>
					</div>
					<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
					    <div class="panel-body">
					        <ul>
		        				<li><?php echo e(trans('raffle_ticket.policies.policy_1')); ?></li>
		        				<li><?php echo e(trans('raffle_ticket.policies.policy_2')); ?></li>
		        				<li><?php echo e(trans('raffle_ticket.policies.policy_3')); ?></li>
		        				<li><?php echo e(trans('raffle_ticket.policies.policy_4')); ?></li>
		        				<li><?php echo e(trans('raffle_ticket.policies.policy_5')); ?></li>
					        </ul>
					        <p class="text-muted text-justify"><b><?php echo e(trans('raffle_ticket.policies.note')); ?></b></p>
					    </div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php if(Session::has('mensaje')): ?>
		<div class="row">
			<div class="col-md-12 col-xs-12">
				<div class="alert alert-dismissible <?php if(Session::get('tipo_mensaje') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('tipo_mensaje') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
		  			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
		  			<?php echo e(session('mensaje')); ?>

		   		</div>
				<div class="clearfix"></div>
			</div>
		</div>
	<?php endif; ?>

	<div class="row">
		
		<div class="col-md-9 col-xs-6">

			
			<ul class="list-unstyled text-center list-inline">
				<li><i class="fa fa-square reserved-color fa-lg""></i> <b> <?php echo e(trans('raffle_ticket.signals.reserved')); ?></b></li>
				<li><i class="fa fa-square selected-now-color fa-lg"> </i> <b> <?php echo e(trans('raffle_ticket.signals.selected')); ?></b></li>
				<li><i class="fa fa-square available-color fa-lg"></i> <b> <?php echo e(trans('raffle_ticket.signals.available')); ?></b></li>
			</ul>
			<hr>
			<?php $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $raffle): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<form action="<?php echo e(route('list.buy.ticket.add')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="raffle_number" value="<?php echo e($raffle['raffle_number']); ?>">
					<div class="col-md-2 col-xs-4">
						<div class="panel panel-success">
		  					<div class="panel-body body-ticket <?php if(existOnCart($raffle['raffle_number'])): ?> selected-now <?php else: ?> available <?php endif; ?>">
								<h1 class="text-center"><b><?php echo e($raffle['raffle_number']); ?></b></h1>
		  					</div>
		  					<div class="panel-footer footer-ticket">
		  						<button class="btn btn-primary btn-block btn-xs text-center btn-add-cart-ticket" <?php if(existOnCart($raffle['raffle_number'])): ?> disabled <?php endif; ?> title="<?php echo e(trans('raffle_ticket.add_cart')); ?>" alt="<?php echo e(trans('raffle_ticket.add_cart')); ?>"><i class="fa fa-cart-plus"></i></button>
		  					</div>
						</div>
					</div>
				</form>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			<div class="clearfix"></div>
			<div class="row text-center">
				<?php echo e($raffles->links()); ?>

			</div>
		</div>
		
		<div class="col-md-3 col-xs-6">
			<div class="cart-place">
				<div class="panel panel-info">
					<div class="panel-heading">
						<div class="panel-title">
							<div class="row">
								<div class="col-xs-12">
									<h5><span class="glyphicon glyphicon-shopping-cart"></span> <?php echo e(trans('raffle_ticket.shopping_cart_title')); ?></h5>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-body">
						<?php if(session()->has('cart')): ?>
							<div class="row">
								<?php $__currentLoopData = session()->get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?> 
									<div class="col-xs-4">
										<h6 class="product-name"><strong>Ticket # <?php echo e($item['raffle_number']); ?> </strong></h6>
									</div>
									<div class="col-xs-3">
										<h6><strong><?php echo e($item['points']); ?> Pnts.</h6>
									</div>
									<div class="col-xs-3">
										<h6><strong>$ <?php echo e($item['price']); ?></h6>
									</div>
									<div class="col-xs-2">
										<form action="<?php echo e(route('list.buy.ticket.remove')); ?>" method="POST">
											<?php echo e(csrf_field()); ?>

											<input type="hidden" name="ticket_index" value="<?php echo e($key); ?>">
											<input type="hidden" name="raffle_number" value="<?php echo e($item['raffle_number']); ?>">
											<button type="submit" class="btn btn-link btn-xs btn-remove" alt="<?php echo e(trans('raffle_ticket.delete_cart')); ?>" title="<?php echo e(trans('raffle_ticket.delete_cart')); ?>">
												<span class="glyphicon glyphicon-trash"> </span>
											</button>
										</form>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</div>
							<hr>
						<?php else: ?>
							<p class="text-muted"><b><?php echo e(trans('raffle_ticket.no_ticket_selected')); ?></b></p>
							<hr>
						<?php endif; ?>
					</div>
					<div class="panel-footer">
						<div class="row text-center">
							<div class="col-xs-6">
								<h4 class="text-right">Total <strong>$ <?php echo e(session()->has('total_sum') ?  session()->get('total_sum') : "0.00"); ?>   </strong></h4>
							</div>
							<div class="col-xs-6">
								<form action="<?php echo e(route('website.paypal.buyticket')); ?>" method="post">
									<?php echo e(csrf_field()); ?>

									<button type="button" class="btn btn-success btn-block" alt="<?php echo e(trans('raffle_ticket.buy_ticket_button')); ?>" title="<?php echo e(trans('raffle_ticket.buy_ticket_button')); ?>">
										<i class="fa fa-paypal" aria-hidden="true"></i> <?php echo e(trans('raffle_ticket.buy_ticket_button')); ?>

									</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>