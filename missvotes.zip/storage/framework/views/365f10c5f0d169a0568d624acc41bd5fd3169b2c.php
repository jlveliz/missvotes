<?php $__env->startSection('content'); ?>
	<div class="row">
		<h1 class="text-center"> <?php echo app('translator')->get('form_process_apply.tittle_process'); ?></h1>
	</div>
	<div class="row">
		<div class="col-md-12 col-xs-12 col-lg-,12">
			<!-- Nav tabs -->
			 <ul id="process-tab" class="nav nav-tabs" role="tablist">
			   <li id="country-tab" role="presentation" class="<?php if($existApply->process_status == 1): ?> active <?php endif; ?>">
			   		<a href="#countries" aria-controls="countries" role="tab" data-toggle="tab"><?php echo app('translator')->get('form_process_apply.country_tab'); ?></a>
			   	</li>
			   <li id="pay-tab" role="presentation" class="<?php if($existApply->process_status <= 1): ?> disabled <?php endif; ?>  <?php if($existApply->process_status == 2): ?> active <?php endif; ?>">
			   		<a href="#pay" aria-controls="pay" role="tab" data-toggle="tab"><?php echo app('translator')->get('form_process_apply.fee_tab'); ?></a>
			   	</li>
			   <li id="subscription-tab" role="presentation" class="<?php if($existApply->process_status <= 2): ?> disabled <?php endif; ?> <?php if($existApply->process_status == 3): ?> active <?php endif; ?>">
			   		<a href="#aplication" aria-controls="aplication" role="tab" data-toggle="tab"><?php echo app('translator')->get('form_process_apply.app_tab'); ?></a>
			   	</li>
			   <li id="success-tab" role="presentation" class="<?php if($existApply->process_status <= 3): ?> disabled <?php endif; ?> <?php if($existApply->process_status == 4): ?> active <?php endif; ?>">
			   		<a href="#status" aria-controls="status" role="tab" data-toggle="tab"><?php echo app('translator')->get('form_process_apply.status_tab'); ?></a>
			   	</li>
			 </ul>

			 <!-- Tab panes -->
			 <div class="tab-content">
			 	
			   <div role="tabpanel" class="tab-pane fade in active" id="countries">
			   		<div class="process-content">
				   		<p><b>1.- <?php echo app('translator')->get('form_process_apply.sel_country_lbl'); ?></b></p>
				   		<div class="row">
				   			<div class="col-md-12 col-lg-12">
				   				<?php if($existApply->process_status < 3): ?>
					   				<ul class="list-unstyled list-inline text-center" id="menu-countries">
					   					<li <?php if($existApply->country_code_selected == 'US'): ?> class="country-selected" <?php endif; ?>>
					   						<a class="country-audition" href="#" data-code="US" title="Estados Unidos" alt="Estados Unidos"><img class="image-responsive" src="<?php echo e(asset('public/images/eeuu_flag.png')); ?>"> <br> US</a> 
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'MX'): ?> class="country-selected" <?php endif; ?>>
					   						<a class="country-audition" href="#" data-code="MX" title="México" alt="México"><img class="image-responsive" src="<?php echo e(asset('public/images/mx_flag.png')); ?>"> <br> MÉXICO</a> 
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'HN'): ?> class="country-selected" <?php endif; ?>>
					   						<a class="country-audition" href="#" data-code="HN" title="Honduras" alt="Honduras"><img class="image-responsive" src="<?php echo e(asset('public/images/ho_flag.png')); ?>"> <br> HONDURAS</a> 
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'GT'): ?> class="country-selected" <?php endif; ?>>
					   						<a class="country-audition" href="#" data-code="GT" title="Guatemala" alt="Guatemala" title=""><img class="image-responsive" src="<?php echo e(asset('public/images/gu_flag.png')); ?>"> <br> GUATEMALA</a> 
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'SV'): ?> class="country-selected" <?php endif; ?>>
					   						<a class="country-audition" href="#" data-code="SV" title="El Salvador" alt="El Salvador"><img class="image-responsive" src="<?php echo e(asset('public/images/sl_flag.png')); ?>"> <br> EL SALVADOR</a> 
					   					</li>
					   				</ul>
				   				<?php else: ?>
				   					<ul class="list-unstyled list-inline text-center" id="">
					   					<li <?php if($existApply->country_code_selected == 'US'): ?> class="country-selected" <?php endif; ?>>
					   						<img class="image-responsive clickable" src="<?php echo e(asset('public/images/eu_flag.png')); ?>"> <br> US</a> 
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'MX'): ?> class="country-selected" <?php endif; ?>>
					   						<img class="image-responsive" src="<?php echo e(asset('public/images/mx_flag.png')); ?>"> <br> MÉXICO
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'HN'): ?> class="country-selected" <?php endif; ?>>
					   						<img class="image-responsive" src="<?php echo e(asset('public/images/ho_flag.png')); ?>"> <br> HONDURAS
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'GT'): ?> class="country-selected" <?php endif; ?>>
					   						<img class="image-responsive" src="<?php echo e(asset('public/images/gu_flag.png')); ?>"> <br> GUATEMALA
					   					</li>
					   					<li <?php if($existApply->country_code_selected == 'SV'): ?> class="country-selected" <?php endif; ?>>
					   						<img class="image-responsive" src="<?php echo e(asset('public/images/sl_flag.png')); ?>"> <br> EL SALVADOR
					   					</li>
					   				</ul>
				   				<?php endif; ?>
				   			</div>
				   		</div>
			   		</div>
			   </div>
			   
			   <div role="tabpanel" class="tab-pane fade" id="pay">
			   		<div class="process-content">
		   				<?php if(Session::has('payment-message')): ?>
		   					<div class="row">
		   				        <div class="alert alert-dismissible <?php if(Session::get('payment-type') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('payment-type') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
		   				          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
		   				          <?php echo e(session('payment-message')); ?>

		   				        </div>
		   					</div>
		   			        <div class="clearfix"></div>
		   			    <?php endif; ?>
			   			
			   			<?php if($existApply->payed_at): ?>
			   				<div class="row">
			   					<h2 class="text-center text-success"> <?php echo app('translator')->get('form_process_apply.txt_pay_thanks_lbl'); ?>. </h2>
			   				</div>
			   			<?php else: ?>
			   			<p>
			   				<b>2.- <?php echo app('translator')->get('form_process_apply.txt_price_lbl'); ?></b> <br>
			   				<small><b><?php echo app('translator')->get('form_process_apply.txt_price_off_lbl'); ?></b></small>
			   			</p>
			   			<div class="row">
					   			<div class="col-md-4 col-lg-4 col-sm-8 col-xs-12 col-md-offset-4 text-center">
					   				<h2 id="price-insciption"><small>$</small> 60.00 <br> <small> USD </small></h2>
					   				<form action="<?php echo e(route('pay.paypal.aplication')); ?>" method="POST" accept-charset="utf-8">
					   					<?php echo e(csrf_field()); ?>

					   					<button type="submit" class="btn btn-primary btn-lg btn-block pay-button" data-payment="paypal"><i class="fa fa-paypal"> </i> <b><?php echo app('translator')->get('form_process_apply.lbl_paypal_'); ?></b></button>
					   					
					   				</form>
					   				<h3>O</h3>
					   				<form id="pay-stripe-aplication" action="<?php echo e(route('pay.stripe.aplication')); ?>" method="post">
					   					<?php echo e(csrf_field()); ?>

					   					<input type="hidden" name="stripeToken" id="stripe-pay-token">
					   					<input type="hidden" name="amount" value="6000">
					   					<input type="hidden" name="description" value="Pay Apply Process Miss Panamerican Int">
					   					<button type="button" id="pay-aplication-stripe" class="btn btn-default btn-lg btn-block pay-button" data-email="<?php echo e(Auth::user()->email); ?>" data-amount="6000" data-description="Pay Apply Process Miss Panamerican Int"><i class="fa fa-credit-card"> </i> <b><?php echo app('translator')->get('form_process_apply.lbl_cc_'); ?></b></button>
					   					
					   				</form>
					   			</div>
			   			</div>
			   			<?php endif; ?>
			   		</div>
			   </div>
			   
			   <div role="tabpanel" class="tab-pane fade" id="aplication">
			   		<div class="process-content">
		   				<?php if(Session::has('payment-message')): ?>
		   					<div class="row">
		   				        <div class="alert alert-dismissible <?php if(Session::get('payment-type') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('payment-type') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
		   				          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
		   				          <?php echo e(session('payment-message')); ?>

		   				        </div>
		   					</div>
		   			        <div class="clearfix"></div>
		   			    <?php endif; ?>
			   			<p><b>3.- <?php echo app('translator')->get('form_process_apply.lbl_pls_fill'); ?></b> </p>
			   			<hr>
			   			<div class="row">
			   				<div class="col-md-7 col-lg-7 col-sm-12 col-xs-12 col-md-offset-2">
				   				<form action="<?php echo e(route('insert.precandidate')); ?>" method="POST" class="form-horizontal">
				   					<?php echo e(csrf_field()); ?>

				   					<?php if($countryselected): ?>
				   						<input type="hidden" name="country_id" value="<?php echo e($countryselected); ?>">
				   					<?php endif; ?>
				   						<input type="hidden" name="is_precandidate" value="1">
				   					<div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
				   						<label class="control-label col-sm-6 col-md-6 "><?php echo app('translator')->get('form_process_apply.lbl_name'); ?> </label>
				   						<div class="col-sm-6 col-md-6">
											<input type="text" class="form-control" name="name" value="<?php echo e(isset($precandidate) ?  $precandidate->name :   Auth::user()->name); ?>" autofocus <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
												<?php if($errors->has('name')): ?> <p class="help-block"><?php echo e($errors->first('name')); ?></p> <?php endif; ?>
				   						</div>
				   					</div>

				   					<div class="form-group  <?php if($errors->has('last_name')): ?> has-error <?php endif; ?>">
				   						<label class="control-label col-sm-6 col-md-6"><?php echo app('translator')->get('form_process_apply.lbl_last_name'); ?> </label>
				   						<div class="col-sm-6 col-md-6">
											<input type="text" class="form-control" name="last_name" value="<?php echo e(isset($precandidate) ? $precandidate->last_name : Auth::user()->last_name); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
												<?php if($errors->has('last_name')): ?> <p class="help-block"><?php echo e($errors->first('last_name')); ?></p> <?php endif; ?>
				   						</div>
				   					</div>

				   					<div class="form-group <?php if($errors->has('birthdate')): ?> has-error <?php endif; ?>">
				   						<label class="control-label col-sm-6 col-md-6"><?php echo app('translator')->get('form_process_apply.lbl_bday'); ?> </label>
				   						<div class="col-sm-6 col-md-6">
					   						<input type="date" class="form-control"  name="birthdate" value="<?php echo e(isset($precandidate) ? $precandidate->birthdate : old('birthdate')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('birthdate')): ?> <p class="help-block"><?php echo e($errors->first('birthdate')); ?></p> <?php endif; ?>
				   						</div>
				   					</div>

				   					<div class="form-group <?php if($errors->has('placebirth')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6"><?php echo app('translator')->get('form_process_apply.lbl_bplace'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
						   					<input type="text" class="form-control" name="placebirth" value="<?php echo e(isset($precandidate) ? $precandidate->placebirth : old('placebirth')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
						   					<?php if($errors->has('placebirth')): ?> <p class="help-block"><?php echo e($errors->first('placebirth')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="email"><?php echo app('translator')->get('form_process_apply.lbl_email'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
						   					<input class="form-control" type="email" name="email" id="email" value="<?php echo e(isset($precandidate) ? $precandidate->email  : Auth::user()->email); ?>" readonly>
						   					<?php if($errors->has('email')): ?> <p class="help-block"><?php echo e($errors->first('email')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('phone_number')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="phone_number"><?php echo app('translator')->get('form_process_apply.lbl_phone'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
						   					<input type="text" class="form-control" name="phone_number" id="phone_number" value="<?php echo e(isset($precandidate) ?  $precandidate->phone_number : old('phone_number')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
						   					<?php if($errors->has('phone_number')): ?> <p class="help-block"><?php echo e($errors->first('phone_number')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('how_did_you_hear_about_us')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="how_did_you_hear_about_us"><?php echo app('translator')->get('form_process_apply.lbl_heard'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
					   						<select class="form-control" name="how_did_you_hear_about_us" id="how_did_you_hear_about_us" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   							<option value="null">--Seleccione--</option>
					   							<option value="brochure" <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'brochure') || old('how_did_you_hear_about_us') == 'brochure'): ?> selected <?php endif; ?>>Brochure</option>
					   							<option value="facebook"  <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'facebook') || old('how_did_you_hear_about_us') == 'facebook'): ?> selected <?php endif; ?>>Facebook</option>
					   							<option value="friend" <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'friend') || old('how_did_you_hear_about_us') == 'friend'): ?> selected <?php endif; ?>>Friend</option>
					   							<option value="former_constentant" <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'former_constentant') || old('how_did_you_hear_about_us') == 'former_constentant'): ?> selected <?php endif; ?>>Former Constentant</option>
					   							<option value="online_ad"  <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'online_ad') || old('how_did_you_hear_about_us') == 'online_ad'): ?> selected <?php endif; ?>>Online AD</option>
					   							<option value="school_teacher" <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'school_teacher') || old('how_did_you_hear_about_us') == 'school_teacher'): ?> selected <?php endif; ?>>School Teacher/Coach</option>
					   							<option value="website_google" <?php if( (isset($precandidate) && $precandidate->how_did_you_hear_about_us == 'website_google') || old('how_did_you_hear_about_us') == 'website_google'): ?> selected <?php endif; ?>>Website / Google Search</option>
					   						</select>
					   						<?php if($errors->has('how_did_you_hear_about_us')): ?> <p class="help-block"><?php echo e($errors->first('how_did_you_hear_about_us')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('height')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="height"><?php echo app('translator')->get('form_process_apply.size'); ?></label>
					   					<div class="col-sm-2 col-md-2">
					   						<select name="height_type_measure" id="height_type_measure" class="form-control" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   							<option value="cm" <?php if( (isset($precandidate) && $precandidate->height_type_measure == 'cm') || old('height_type_measure') == 'cm'): ?> selected <?php endif; ?>>cm</option>
					   							<option value="ft" <?php if( (isset($precandidate) && $precandidate->height_type_measure == 'ft') || old('height_type_measure') == 'ft'): ?> selected <?php endif; ?>>ft</option>
					   						</select>
											<?php if($errors->has('height')): ?> <p class="help-block"><?php echo e($errors->first('height')); ?></p> <?php endif; ?>
					   					</div>
					   					<div class="col-sm-3 col-md-3">
						   					<input type="text" id="height"  name="height" id="height" class="form-control" value="<?php echo e(isset($precandidate)  ? $precandidate->height :  old('height')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
							<?php if($errors->has('height')): ?> <p class="help-block"><?php echo e($errors->first('height')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('weight')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="weight"><?php echo app('translator')->get('form_process_apply.lbl_weight'); ?></label>
					   					<div class="col-sm-2 col-md-2">
					   						<select name="weight_type_measure" id="weight_type_measure" class="form-control" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   							<option value="lb" <?php if( (isset($precandidate) && $precandidate->weight_type_measure == 'lb') || old('weight_type_measure') == 'lb'): ?> selected <?php endif; ?>>lb</option>
					   							<option value="kg" <?php if( (isset($precandidate) && $precandidate->weight_type_measure == 'kg') || old('weight_type_measure') == 'kg'): ?> selected <?php endif; ?>>kg</option>
					   						</select>
											<?php if($errors->has('weight_type_measure')): ?> <p class="help-block"><?php echo e($errors->first('weight_type_measure')); ?></p> <?php endif; ?>
					   					</div>
					   					<div class="col-sm-3 col-md-3">
					   						<input type="text" name="weight" id="weight" class="form-control" value="<?php echo e(isset($precandidate)  ? $precandidate->weight :  old('weight')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
											<?php if($errors->has('weight')): ?> <p class="help-block"><?php echo e($errors->first('weight')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('address')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="address"><?php echo app('translator')->get('form_process_apply.lbl_adress'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
						   					<input type="text" id="address" class="form-control" name="address" value="<?php echo e(isset($precandidate) && $precandidate->address ?  $precandidate->address : old('address')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
						   					<?php if($errors->has('address')): ?> <p class="help-block"><?php echo e($errors->first('address')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('city')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="city"><?php echo app('translator')->get('form_process_apply.lbl_city'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
					   						<input type="text" class="form-control" name="city" value="<?php echo e(isset($precandidate) && $precandidate->city ?  $precandidate->city : old('city')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('address')): ?> <p class="help-block"><?php echo e($errors->first('city')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('state_province')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="state_province"><?php echo app('translator')->get('form_process_apply.lbl_state'); ?>  </label>
					   					<div class="col-sm-6 col-md-6">
					   						<input type="text" class="form-control" id="state_province" name="state_province" value="<?php echo e(isset($precandidate) && $precandidate->state_province ?  $precandidate->state_province : old('state_province')); ?>" <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('state_province')): ?> <p class="help-block"><?php echo e($errors->first('state_province')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('bust_measure')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="bust_measure"><?php echo app('translator')->get('form_process_apply.lbl_bust'); ?></label>
					   					<div class="col-sm-3 col-md-3">
					   						<input type="number" step="1" min="1" name="bust_measure" id="bust_measure" class="form-control" value="<?php echo e(isset($precandidate)  ? $precandidate->bust_measure :  old('bust_measure')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>> 
					   						<?php if($errors->has('bust_measure')): ?> <p class="help-block"><?php echo e($errors->first('bust_measure')); ?> </p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('waist_measure')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="waist_measure"><?php echo app('translator')->get('form_process_apply.lbl_waist'); ?></label>
					   					<div class="col-sm-3 col-md-3">
					   						<input type="number" step="1" min="1" name="waist_measure" id="waist_measure" class="form-control" value="<?php echo e(isset($precandidate)  ? $precandidate->waist_measure :  old('waist_measure')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('waist_measure')): ?> <p class="help-block"><?php echo e($errors->first('waist_measure')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('hip_measure')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="hip_measure"><?php echo app('translator')->get('form_process_apply.lbl_hip'); ?></label>
					   					<div class="col-sm-3 col-md-3">
					   						<input type="number" step="1" min="1" name="hip_measure" id="hip_measure" class="form-control" value="<?php echo e(isset($precandidate)  ? $precandidate->hip_measure :  old('hip_measure')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('hip_measure')): ?> <p class="help-block"><?php echo e($errors->first('waist_measure')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('hair_color')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="hair_color"><?php echo app('translator')->get('form_process_apply.lbl_hair'); ?></label>
					   					<div class="col-sm-3 col-md-3">
						   					<input class="form-control" type="text" name="hair_color" id="hair-color"   value="<?php echo e(isset($precandidate)  ? $precandidate->hair_color :  old('hair_color')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
						   					<?php if($errors->has('hair_color')): ?> <p class="help-block"><?php echo e($errors->first('hair_color')); ?></p> <?php endif; ?>				
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('eye_color')): ?> has-error <?php endif; ?>">
					   					<label class="control-label col-sm-6 col-md-6" for="eye_color"><?php echo app('translator')->get('form_process_apply.lbl_eye'); ?></label>
					   					<div class="col-sm-3 col-md-3">
					   						<input class="form-control" type="text" name="eye_color" id="eye-color"   value="<?php echo e(isset($precandidate)  ? $precandidate->eye_color :  old('eye_color')); ?>"  <?php if(isset($precandidate)): ?> disabled <?php endif; ?>>
					   						<?php if($errors->has('eye_color')): ?> <p class="help-block"><?php echo e($errors->first('eye_color')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('dairy_philosophy')): ?> has-error <?php endif; ?>">
					   					<label class="col-sm-6 col-md-6 control-label" for="dairy_philosophy"><?php echo app('translator')->get('form_process_apply.lbl_phil'); ?> </label>
					   					<div class="col-sm-6 col-md-6">
					   						<textarea class="form-control" name="dairy_philosophy" id="dairy_philosophy"<?php if(isset($precandidate)): ?> disabled <?php endif; ?>><?php echo e(isset($precandidate)? $precandidate->dairy_philosophy : old('dairy_philosophy')); ?></textarea>
					   						<?php if($errors->has('dairy_philosophy')): ?> <p class="help-block"><?php echo e($errors->first('dairy_philosophy')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<div class="form-group <?php if($errors->has('why_would_you_win')): ?> has-error <?php endif; ?>">
					   					<label class="col-sm-6 col-md-6 control-label" for="why_would_you_win"><?php echo app('translator')->get('form_process_apply.lbl_win'); ?> <?php echo e(config('app.name')); ?> ? </label>
					   					<div class="col-sm-6 col-md-6">
					   						<textarea class="form-control" name="why_would_you_win" id="why_would_you_win" <?php if(isset($precandidate)): ?> disabled <?php endif; ?> rezise><?php echo e(isset($precandidate)  ? $precandidate->why_would_you_win :  old('why_would_you_win')); ?></textarea>
					   						<?php if($errors->has('why_would_you_win')): ?> <p class="help-block"><?php echo e($errors->first('why_would_you_win')); ?></p> <?php endif; ?>
					   					</div>
					   				</div>

					   				<?php if(!isset($precandidate)): ?>
					   				<div class="form-group <?php if($errors->has('g-recaptcha-response')): ?> has-error <?php endif; ?>" style="margin-left: 25%">
					   					<?php echo Recaptcha::render(); ?>

					   					<?php if($errors->has('g-recaptcha-response')): ?> <p class="help-block"><?php echo e($errors->first('g-recaptcha-response')); ?></p> <?php endif; ?>
					   				</div>
					   				<hr>
					   				<div class="form-group">
					   					<button id="subscribe" type="submit" class="subscribe-button btn btn-primary btn-lg btn-block" id="save"><?php echo app('translator')->get('form_process_apply.lbl_btn_ins'); ?></button>
					   				</div>
					   				<?php endif; ?>
				   				</form>
			   				</div>
			   			</div>
			   		</div>
			   </div>
			   
			   <div role="tabpanel" class="tab-pane fade" id="status">
			   		<div class="process-content">
			   			<h3><?php echo app('translator')->get('form_process_apply.lbl_done'); ?></h3>
			   			<div class="row">
			   				<div class="col-md-6 col-lg-6 text-center col-md-offset-3">
			   					<img class="image-responsibe" src="<?php echo e(asset('public/images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>" title="<?php echo e(config('app.name')); ?>">
			   					<h4><?php echo app('translator')->get('form_process_apply.lbl_last-message'); ?></h4>
			   				</div>
			   			</div>
			   		</div>
			   </div>
			 </div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/form-process.css')); ?>">
<style>
	textarea {
		resize: none
	}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://checkout.stripe.com/checkout.js"></script>
<script type="text/javascript">

$(document).ready(function() {

	<?php if($existApply->process_status == 1 ): ?>
    	window.location.hash = $("#country-tab a").attr('href');
    	// $('#process-tab a[href="#countries"]').tab('show');
    	$('#process-tab a:first').tab('show')
    <?php endif; ?>

    <?php if($existApply->process_status == 2 ): ?> 
    	window.location.hash = $("#pay-tab a").attr('href');
    	// $('#process-tab a[href="#pay"]').tab('show');
    	$('#process-tab a:first').tab('show')
    <?php endif; ?>

    <?php if($existApply->process_status == 3 ): ?> 
    	window.location.hash = $("#subscription-tab a").attr('href');
    	// $('#process-tab a[href="#aplication"]').tab('show');
    	$('#process-tab a:first').tab('show')
    <?php endif; ?> 

    <?php if($existApply->process_status == 4 ): ?> 
    	window.location.hash = $("#success-tab a").attr('href');
    	// $('#process-tab a[href="#status"]').tab('show');
    	$('#process-tab a:first').tab('show')
    <?php endif; ?>
   	

	var hash = window.location.hash;
  	hash && $('ul.nav a[href="' + hash + '"]').tab('show');

  
    $('a[data-toggle="tab"]').on('click', function(){
        if ($(this).parent('li').hasClass('disabled')) {
            return false;
        }
        var scrollmem = $('body').scrollTop() || $('html').scrollTop();
    	window.location.hash = this.hash;
    	$('html,body').scrollTop(scrollmem);
    });



    $(".country-audition").on('click', function(event) {
    	event.preventDefault();
    	var countryCode = $(this).data('code');
    	if(!countryCode) return false;
    	$(".country-audition").parent('li').removeClass('country-selected'); //remove all class
    	$(this).parent('li').addClass('country-selected');
    	//next tab
    	var hash = $('#process-tab li:eq(1) a').attr('href');
    	window.location.hash = hash;
    	$('#process-tab li:eq(1) a').tab('show') // Select third tab (0-indexed)
    	$("#pay-tab").removeClass('disabled');


    	$.ajax({
    		url: '/apply/update-aplication-process',
    		type: 'POST',
    		data: {
    			country_code: countryCode,
    			process_status: 2
    		}
    	});
    	
    });

    $(".pay-button").on('click', function(event) {
    	// var payment = $(this).data(payment);
    	// if(!payment) return false;
    	// //next tab
    	// var hash = $('#process-tab li:eq(2) a').attr('href');
    	// window.location.hash = hash;
    	// $('#process-tab li:eq(2) a').tab('show') // Select third tab (0-indexed)
    	// $("#subscription-tab").removeClass('disabled');
    });

    $(".subscribe-button").on('click',  function(event) {
    	// event.preventDefault();
    	// $('#process-tab li:eq(3) a').tab('show') // Select third tab (0-indexed)
    	// $("#subscription-tab").removeClass('disabled');
    });




    // stripe

   var handlerPay = StripeCheckout.configure({
	  key: '<?php echo e(config('services.stripe.key')); ?>',
	  image: '<?php echo e(asset('public/images/queen-mini.png')); ?>',
	  locale: 'auto',
	  name: '<?php echo e(config('app.name')); ?>',
	  description : 'Pay Apply Process Miss Panamerican Int',
	  token : function(token){
	  	$("#stripe-pay-token").val(token.id);
	  	//submit the magic form :3
	  	$("#pay-stripe-aplication").submit();
	  }
	});

   	$("#pay-aplication-stripe").on('click', function(event) {
   		event.preventDefault();
   		var _this = $(this);
      	handlerPay.open({
    		description: _this.data('description'),
    		amount: _this.data('amount'),
    		email: _this.data('email')
  		});
   		/* Act on the event */
   	});


   	$("#height_type_measure").on('change', function(event) {
   		var value = $(this).val();
   		if(value == 'cm') {
   			$("#height").attr({
   				// min: '1.67',
   				// value: '1.67'
   			});
   		} else {
   			$("#height").attr({
   				// min: '5.5',
   				// value: '5.5'
   			});
   		}
   	});	

   	$("#weight_type_measure").on('change', function(event) {
   		var value = $(this).val();
   		if(value == 'lb') {
   			$("#weight").attr({
   				min: '104',
   				value: '104'
   			});
   		} else {
   			$("#weight").attr({
   				min: '57',
   				value: '57'
   			});
   		}
   	});

 //   	 $("#height").keydown(function (e) {
 //        // Allow: backspace, delete, tab, escape, enter and .
 //        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
 //             // Allow: Ctrl+A, Command+A
 //            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
 //             // Allow: home, end, left, right, down, up
 //            (e.keyCode >= 35 && e.keyCode <= 40)) {
 //                 // let it happen, don't do anything
 //                 return;
 //        }
 //        // Ensure that it is a number and stop the keypress
 //        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
 //            e.preventDefault();
 //        }
 //    });
	
	// $("#weight").keydown(function (e) {
 //        // Allow: backspace, delete, tab, escape, enter and .
 //        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
 //             // Allow: Ctrl+A, Command+A
 //            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
 //             // Allow: home, end, left, right, down, up
 //            (e.keyCode >= 35 && e.keyCode <= 40)) {
 //                 // let it happen, don't do anything
 //                 return;
 //        }
 //        // Ensure that it is a number and stop the keypress
 //        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
 //            e.preventDefault();
 //        }
 //    });


});

	 // Close Checkout on page navigation:
	window.addEventListener('popstate', function() {
  		handlerPay.close();
	});

</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
	textarea {
		resize: none
	}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>