<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
  <div class="panel-heading">Usuarios</div>

  <div class="panel-body">
  	   <?php if(Session::has('mensaje')): ?>
        <div class="alert alert-dismissible <?php if(Session::get('tipo_mensaje') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('tipo_mensaje') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <?php echo e(session('mensaje')); ?>

           </div>
        <div class="clearfix"></div>
       <?php endif; ?>
     	<table id="user-datatable" class="table table-bordered">
     		<caption>Listado de Usuarios <a class="pull-right btn btn-primary" href="<?php echo e(route('users.create')); ?>" title="Crear">Crear Usuario</a></caption>
     		<thead>
     			<tr>
     				<th>Nombre</th>
     				<th>Email</th>
     				<th>Dirección</th>
     				<th>Último Acceso</th>
     				<th>Fecha creación/Actualización</th>
     				<th>Acción</th>
     			</tr>
     		</thead>
     		<tbody>
     			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
       			<tr>
       				<td><?php echo e($user->name); ?></td>
       				<td><?php echo e($user->email); ?></td>
       				<td><?php echo e($user->address); ?></td>
       				<td><?php if($user->last_login): ?><?php echo e($user->last_login); ?> <?php else: ?> - <?php endif; ?></td>
       				<td><?php echo e($user->created_at); ?> / <?php echo e($user->updated_at); ?></td>
       				<td class="text-center">
       					<form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
       						<a href="<?php echo e(route('users.edit',$user->id)); ?>" title="Editar" class="btn btn-xs btn-warning"> Editar</a>
       						<?php if(Auth::user()->id != $user->id): ?>
         						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
         						<input type="hidden" name="_method" value="DELETE">
         						<button type="submit" title="Eliminar" class="btn btn-xs btn-danger"> Eliminar</button>
       						<?php endif; ?>
       					</form>
       				</td>
       			</tr>
     			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
     		</tbody>
     	</table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function(){
      $('#user-datatable').DataTable({
        "language": {
          "url": "../public/js/datatables/json/es.json"
        }
      });
  });
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>