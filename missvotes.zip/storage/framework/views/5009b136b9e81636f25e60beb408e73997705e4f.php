<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
  <div class="panel-heading">Ranking</div>
  <div class="panel-body">
  	<table id="ranking-datatable" class="table table-bordered">
  		<thead>
	  		<tr>
	  			<th>Candidata</th>
	  			<th>País</th>
	  			<th>Puntaje</th>
	  		</tr>
  		</thead>
  		<tbody>
	  		<?php $__currentLoopData = $votes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>  $vote): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	  	 		<tr <?php if($index == 0): ?> class="success" <?php endif; ?>>
	  				<td><?php if($index == 0): ?> <b><?php echo e($vote->miss->name); ?> <?php echo e($vote->miss->last_name); ?></b> <?php else: ?> <?php echo e($vote->miss->name); ?> <?php echo e($vote->miss->last_name); ?> <?php endif; ?> </td>
	  				<td><?php if($index == 0): ?> <b><?php echo e($vote->miss->country->name); ?></b> <?php else: ?> <?php echo e($vote->miss->country->name); ?> <?php endif; ?></td>
	  				<td><?php if($index == 0): ?> <b><?php echo e($vote->sumatory); ?> Puntos</b> <?php else: ?> <?php echo e($vote->sumatory); ?> Puntos <?php endif; ?> </td>
	  			</tr>
	  		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  		</tbody>
  	</table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function(){
      // $('#ranking-datatable').DataTable({
      //   "language": {
      //     "url": "../public/js/datatables/json/es.json",
      //   },
      //   "order": [[ 2, "desc" ]],
      //   "ordering": false,
      // });
  });
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>