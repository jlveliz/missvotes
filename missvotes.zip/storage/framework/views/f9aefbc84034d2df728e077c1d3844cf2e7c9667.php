<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-lg-4 col-xs-12 col-md-offset-4 container-page-auth">
            <div class="row">
                <h1 class="text-center"><?php echo e(trans('auth.reset_password_title')); ?></h1>
            </div>
            
            <div class="row">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
            </div>
            
            <div class="row">
                <form role="form" method="POST" action="<?php echo e(url('auth/password/reset')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <input type="hidden" name="token" value="<?php echo e($token); ?>">

                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <input id="email" type="email" placeholder="<?php echo e(trans('auth.reset_password_fields.email')); ?>" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input id="password" type="password" class="form-control" name="password" placeholder="<?php echo e(trans('auth.reset_password_fields.password')); ?>" required>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="<?php echo e(trans('auth.reset_password_fields.confirm_password')); ?>" required>

                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                        <?php endif; ?>
                        
                    </div>

                    <button type="submit" class="login btn btn-primary btn-block loginmodal-submit">
                        <?php echo e(trans('auth.reset_password_options.submit')); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>