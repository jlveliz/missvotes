<nav class="navbar navbar-inverse navbar-fixed-top navbar-main">
    <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

        <ul class="nav navbar-nav">
            <?php if(Auth::user() && !Auth::user()->is_admin): ?>
                
               
                <li>
                    <a href="<?php echo e(route('apply.requirements')); ?>" class="btn btn-update-membership-or-buy"  alt="<?php echo e(trans('app.apply_now')); ?>" title="<?php echo e(trans('app.apply_now')); ?>"> <?php echo e(trans('app.apply_now')); ?></a>
                </li>

                <li style="margin-left: 2px">
                    <a href="<?php echo e(route('list.buy.ticket')); ?>" class="btn btn-update-membership-or-buy"  alt="<?php echo e(trans('app.win_travel')); ?>" title="<?php echo e(trans('app.win_travel')); ?>"> <?php echo e(trans('app.win_travel')); ?></a>
                </li>
               
            <?php endif; ?>
           

        </ul>

        <?php if(!Auth::user()): ?>
            
        <?php else: ?>
             <!-- Right Side Of Navbar -->
            <ul class="nav navbar-nav navbar-right">
                
                <?php if(Auth::user()->is_admin): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>" title="<?php echo e(trans('app.go_administration')); ?>"><?php echo e(trans('app.go_administration')); ?></a>
                    </li>
                <?php else: ?> 
                    <li>
                        <a href="<?php echo e(route('website.account')); ?>" title="<?php echo e(trans('app.my_account')); ?>"><?php echo e(trans('app.my_account')); ?></a>
                    </li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(url('auth/logout')); ?>"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                        <?php echo e(trans('app.logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(url('auth/logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>

                <?php if(App::isLocale('en')): ?>
                    <li>
                        <form action="<?php echo e(route('website.locale')); ?>">
                            
                            <input type="hidden" name="lang" value="es">
                            <button  type="submit" class="btn btn-update-membership-or-buy" > Spanish</button>
                            
                        </form>
                    </li>
                <?php else: ?>
                    <li>
                        <form action="<?php echo e(route('website.locale')); ?>">
                            
                            <input type="hidden" name="lang" value="en">
                            <button  type="submit" class="btn btn-update-membership-or-buy"> Inglés</button>
                            
                        </form>
                    </li>
                <?php endif; ?>

               
            </ul>
        <?php endif; ?>
    </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>