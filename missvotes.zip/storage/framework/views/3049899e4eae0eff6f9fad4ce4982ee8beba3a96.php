<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8">
    </head>
    <body>
       <img src="<?php echo e(asset('public/images/queen-mini.png')); ?>" alt="<?php echo e(config('app.name')); ?>" title="<?php echo e(config('app.name')); ?>">
        <h2><?php echo e(config('app.name')); ?></h2>
        <br>
        <br>
        <div>
            <p><?php echo e(trans('email.casting.hi')); ?> <b><?php echo e($precandidate->name); ?> <?php echo e($precandidate->last_name); ?></b>, <?php echo e(trans('email.casting.thanks')); ?> <b> <?php echo e(trans('email.casting.welcome')); ?></p>
            <br>
            <br>
            <h2><?php echo e(trans('email.casting.casting_code')); ?> <?php echo e($precandidate->code); ?></h2>
            <br>
            <br>

            <p><?php echo e(trans('email.casting.title_data')); ?></p>

            <br>
            <br>

            <p><u><?php echo e(trans('email.casting.place')); ?></u></p>
            <p>Moda 2000 <br> 845 N. Euclid St. Anaheim CA 92801</p>

            <br>
            <br>
            <p><u><?php echo e(trans('email.casting.days_hours_casting')); ?></u></p>
            
        </div>

    </body>
</html>