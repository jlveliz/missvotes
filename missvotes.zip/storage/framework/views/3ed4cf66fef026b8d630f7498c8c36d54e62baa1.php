<?php $__env->startSection('content'); ?>
<br><br>
<div class="row text-center">
    <?php echo e($misses->links()); ?>

</div>
<div class="row gallery-container">
	<?php $__currentLoopData = $misses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miss): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <a href="<?php echo e(route('website.miss.show',$miss->slug)); ?>">
            <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe thumbnail " style="background-image: url('<?php echo e(config('app.url') .'/'. $miss->photos()->first()->path); ?>'); ">
                <div class="middle">
                    <div class="text"><?php echo e($miss->country->name); ?></div>
                </div>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

</div>
<div class="row text-center">
    <?php echo e($misses->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>