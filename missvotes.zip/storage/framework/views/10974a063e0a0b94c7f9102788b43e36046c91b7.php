<div class="col-md-8 col-xs-12">
    <?php if(!Auth::user()->client->current_membership()): ?>
        <div class="col-xs-12 col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <?php echo app('translator')->get('membership.free_lbl'); ?> 
                            <br>
                                <b>(<?php echo app('translator')->get('membership.act_membership_lbl'); ?>)</b>
                        </h3>
                </div>
                <div class="panel-body">
                    <div class="the-price">
                        <h1>
                            $0.00<span class="subscript"></span></h1>
                    </div>
                    <table class="table">                        
                        <tr>
                            <td class="text-justify">
                            <?php echo app('translator')->get('membership.includes_membership_lbl'); ?>:
                            <ul>
                                <li><?php echo app('translator')->get('membership.free_1_membership_lbl'); ?></li>
                                <li><?php echo app('translator')->get('membership.free_2_membership_lbl'); ?></li>
                                <li><?php echo app('translator')->get('membership.free_3_membership_lbl'); ?></li>
                            </ul>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php if(Auth::user()->client->current_membership()): ?>
                    <div class="panel-footer">
                        <a href="#" class="btn btn-success" role="button"><?php echo app('translator')->get('membership.update_btn'); ?></a>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    <?php endif; ?>
    
    <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-xs-12 col-md-6">
            <div class="panel <?php if(Auth::user()->client->current_membership() && (Auth::user()->client->current_membership()->membership_id ==  $membership->id) ): ?> panel-primary <?php else: ?>  panel-success <?php endif; ?>">
                      
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <?php echo e($membership->name); ?>

                        <?php if(Auth::user()->client->current_membership() && (Auth::user()->client->current_membership()->membership_id ==  $membership->id) ): ?>
                        <br>
                            <b>(<?php echo app('translator')->get('membership.act_membership_lbl'); ?>)</b>
                    <?php endif; ?>
                    </h3>
                </div>
                <div class="panel-body">
                    <div class="the-price">
                        <h1>
                            $<?php echo e($membership->price); ?></h1>
                        
                    </div>
                    <table class="table">
                        <tr>
                            <td>
                               <b> <?php echo app('translator')->get('membership.lbl_membership_lbl'); ?>: </b><?php echo e($membership->duration_time); ?> <?php echo app('translator')->get('membership.tm_membership_lbl'); ?>
                            </td>
                        </tr>

                        <tr>
                            <td class="text-justify">
                            <?php echo app('translator')->get('membership.includes_membership_lbl'); ?>:
                            <ul>
                                <li><?php echo app('translator')->get('membership.prm_1_membership_lbl'); ?></li>
                                <li><?php echo app('translator')->get('membership.prm_2_membership_lbl'); ?></li>
                                <li><?php echo app('translator')->get('membership.prm_3_membership_lbl'); ?></li>
                                <li><?php echo app('translator')->get('membership.prm_4_membership_lbl'); ?></li>
                            </ul>
                        </tr>
                    </table>
                </div>
                <?php if(!Auth::user()->client->current_membership() || !(Auth::user()->client->current_membership()->membership_id ==  $membership->id) ): ?>
                    <div class="panel-footer panel-footer-payments">
                        
                        <form action="<?php echo e(route('website.paypal.subscribe')); ?>" method="post" style="display: inline">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="paypal_email" value="<?php echo e(Auth::user()->email); ?>">
                            <input type="hidden" name="paypal_membership_id" value="<?php echo e($membership->id); ?>">
                            <input type="hidden" name="paypal_membership_name" value="<?php echo e($membership->name); ?>">
                            <input type="hidden" name="paypal_membership_description" value="Pago de membresía <?php echo e($membership->name); ?>">
                            <input type="hidden" name="paypal_membership_amount" value="<?php echo e($membership->price); ?>">
                            <button type="submit" class="btn  btn-sm btn-success" role="button" title="Usar Paypal"><i class="fa fa-paypal"></i> Usar Paypal</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php if(Auth::user()->client->current_membership()): ?>
        <div class="col-xs-12 col-md-6" style="padding-top: 25%">
            <div class="text-center">
                <img style="width: 70%" src="<?php echo e(asset('public/images/logo_square.png')); ?>" alt="<?php echo e(config('app.name')); ?>" title="<?php echo e(config('app.name')); ?>">
            </div>
            <div class="row">
                <h5 class="text-center"><?php echo e(trans('membership.thanks_premium_membership')); ?></h5>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="col-md-4">
    <p class="text-justify"><?php echo app('translator')->get('membership.txt_data_1'); ?>:
    </p>
    <p class="text-primary"><strong><?php echo app('translator')->get('membership.free_sus'); ?></strong></p>
    <p class="text-justify">
    <?php echo app('translator')->get('membership.txt_free_sus'); ?>    
    </p>
    <p class="text-success"><strong><?php echo app('translator')->get('membership.prem_sus'); ?></strong></p>
    <p class="text-justify">
    <?php echo app('translator')->get('membership.txt_prem_sus'); ?>
    </p>
    <p><strong><?php echo app('translator')->get('membership.adi_txt'); ?></strong></p>
</div>


<form id="membeship-form" action="<?php echo e(route('website.stripe.subscribe')); ?>" method="POST" style="visibility: hidden;">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" id="membership-id" name="membership_id" value="">
    <input type="hidden" id="amount" name="amount" value="">
    <input type="hidden" id="stripe-token" name="stripeToken" value="">
</form>
