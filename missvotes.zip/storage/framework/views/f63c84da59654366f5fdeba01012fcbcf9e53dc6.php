<?php $__env->startSection('title','404'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="error-template">
                <h1>
                    Oops!</h1>
                <h2>
                    404 No existe</h2>
                <div class="error-details">
                    Lo Siento un error ha ocurrido, la página no existe
                </div>
                <div class="error-actions">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-home"></span>
                        Volver </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>