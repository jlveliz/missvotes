<?php $__env->startSection('content'); ?>
	<div class="row">
		<h1 class="text-center"><?php echo app('translator')->get('requirement.tittle_process'); ?></h1>
		<div class="col-md-6 col-lg-6 col-xs-12 col-md-offset-3">
			<?php if(Session::has('message')): ?>
        		<div class="alert alert-dismissible <?php if(Session::get('type') == 'success'): ?> alert-info  <?php endif; ?> <?php if(Session::get('type') == 'error'): ?> alert-danger  <?php endif; ?>" role="alert">
          			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          			<?php echo e(session('message')); ?>

           		</div>
        		<div class="clearfix"></div>
        	<?php endif; ?>
			<ol>
				<li><?php echo app('translator')->get('requirement.txt_01'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_02'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_03'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_04'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_05'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_06'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_07'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_08'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_09'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_10'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_11'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_12'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_13'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_14'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_15'); ?></li>
				<li><?php echo app('translator')->get('requirement.txt_16'); ?></li>
			</ol>
			<form action="<?php echo e(route('apply.aceptrequirements')); ?>" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="checkbox">
				    <label>
				      <input type="checkbox" name="acept-terms" value="1"> <?php echo app('translator')->get('requirement.txt_terms'); ?>
				    </label>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('requirement.btn_accept'); ?> </button>
				</div>
			</form>
			<br><br>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>