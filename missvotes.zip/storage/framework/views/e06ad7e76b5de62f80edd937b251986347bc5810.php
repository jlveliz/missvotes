<?php $__env->startSection('content'); ?>
	 <div class="row">
    <div class="col-md-4 col-lg-4 col-xs-12 col-md-offset-4 container-page-auth">
			  <h2 class="text-center"><?php echo e(trans('auth.register_success')); ?></h2><br>
			  <p class="text-muted text-center"><?php echo e(trans('auth.register_success_message')); ?></p>
			  <a type="submit" class="btn btn-primary btn-block" href="<?php echo e(route('website.home')); ?>" value="Aceptar" data-dismiss="modal"><?php echo e(trans('auth.register_success_submit')); ?></a>
			
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>